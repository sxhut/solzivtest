+++
title = "{{ replace .Name "-" " " | title }}"
summary = ""
toc = true
authors = []
tags = []
categories = []
series = []
date =  {{ .Date }}
lastmod = {{ .Date }}
draft = false
+++