+++
# Name
title = ""
role = ""
bio = ""

[[organizations]]
name = ""
url = ""

[[social]]
icon = ""
icon_pack = ""
link = ""

+++
